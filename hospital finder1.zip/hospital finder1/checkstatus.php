<!DOCTYPE html>
<html>
<title>
	checkstatuspage
</title>
<body>
	<h1>Checkupstatus page</h1>
	<div style="text-align: center">
		<div>

<form action="#" method="POST">

	<table>
<tr><td><b style="color: indigo;
    font-size: 20px;">Mobile</b></td>
 <td><input type="text" name="smobile" style="margin-left: 7%;padding-left: 45%;
    padding-right: 45%;margin-bottom: 2%;margin-top: 25px;margin-bottom: 18px;border-style: outset;
    border-color: darkgrey;"><br></td></tr>

<tr><td><b style="color: indigo;
    font-size: 20px;">Patients ID</b></td>
<td><input type="text" name="spid" style="margin-left: 7%;padding-left: 45%;padding-right: 45%;margin-bottom: 2%;margin-bottom: 18px;border-style: outset;
    border-color: darkgrey;"><br></td></tr>

    <tr><td><b style="color: indigo;
    font-size: 20px;">Parients Name</b></td>
 <td><input type="text" name="spname" style="margin-left: 7%;padding-left: 45%;
    padding-right: 45%;margin-bottom: 2%;margin-top: 25px;margin-bottom: 18px;border-style: outset;
    border-color: darkgrey;"><br></td></tr>

<tr><td><b style="color: indigo;
    font-size: 20px;">Age</b></td>
<td><input type="text" name="sage" style="margin-left: 7%;padding-left: 45%;
    padding-right: 45%;margin-bottom: 2%;margin-bottom: 18px;border-style: outset;
    border-color: darkgrey;"><br></td></tr>

 <tr><td><b style="color: indigo;
    font-size: 20px;">Gender</b></td>
 <td><input type="text" name="sgender" style="margin-left: 7%;padding-left: 45%;
    padding-right: 45%;margin-bottom: 2%;margin-top: 25px;margin-bottom: 18px;border-style: outset;
    border-color: darkgrey;"><br></td></tr>

<tr><td><b style="color: indigo;
    font-size: 20px;">ParientID no</b></td>
<td><input type="text" name="spidno" style="margin-left: 7%;padding-left: 45%;
    padding-right: 45%;margin-bottom: 2%;margin-bottom: 18px;border-style: outset;
    border-color: darkgrey;"><br></td></tr>

<tr><td><b style="color: indigo;
    font-size: 20px;">Correntno</b></td>
<td><input type="text" name="scorrentno" style="margin-left: 7%;padding-left: 45%;
    padding-right: 45%;margin-bottom: 2%;margin-bottom: 18px;border-style: outset;
    border-color: darkgrey;"><br></td></tr>



    <tr><td><b style="color: indigo;
    font-size: 20px;">email</b></td>
<td><input type="text" name="semail" style="margin-left: 7%;padding-left: 45%;
    padding-right: 45%;margin-bottom: 2%;margin-bottom: 18px;border-style: outset;
    border-color: darkgrey;"><br></td></tr>    

<tr><td><input type="submit" name="tbl_checkstatus"value="ok"style="margin-left: 100px;"></td></tr>

</form>
</div>

<div>
    <?php
    include("db_connect.php");
    if(isset($_POST ['tbl_checkstatus']))
    {
      $smobile = $_POST['smobile'];
      $spid = $_POST['spid'];
      $spname = $_POST['spname'];
      $sage = $_POST['sage'];
      $sgender = $_POST['sgender'];
      $spidno = $_POST['spidno'];
      $scorrentno = $_POST['scorrentno'];
      $semail =$_POST['semail'];
     
      $sql = "INSERT INTO tbl_checkstatus(smobile,spid,pname,sage,sgender,spidno,scorrentno) VALUES ('$smobile','$spid','$spname','$sage','$sgender','$spidno','$scorrentno')";
      //echo $sql;
      $qry_run = mysqli_query($con,$sql);
      if($qry_run == TRUE)
        echo"<script> alert('Registered')</script>";
   else
      echo"<script> alert('TRY AGAIN!!!')</script>";
    }
    
    ?>
</div>
</body>
</html>
<!DOCTYPE html>

<html>
<head>
	<title>Doctor</title>
</head>
<body style="background-color: white;text-align: center;">
	<h2><b style="margin-right: 18%;">DOCTOR</b></h2>
<div>
<form action="#" method="POST">
	<b style="font-size: larger;">Doctor ID</b>
	<input type="name" name="did" style="
    border-style: outset;
    border-color: snow;
    margin-top: 2%;
    margin-bottom: 1%;
    margin-left: 6%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;">

    <br><b style="font-size: larger;">Doctor Name</b>
    <input type="name" name="dname" style="
    border-style: outset;
    border-color: snow;
    margin-left: 4%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

    <br><b style="font-size: larger;">Spacification</b>
    <input type="name" name="dspacification" style="
    border-style: outset;
    border-color: snow;
    margin-left: 4%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

    <br><b style="font-size: larger;">Qualifications</b>
    <input type="name" name="dqualification" style="
    border-style: outset;
    border-color: snow;
    margin-left: 4%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

    <br><b style="font-size: larger;">DOB</b>
    <input type="name" name="ddob" style="
    border-style: outset;
    border-color: snow;
    margin-left: 3%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

    <br><b style="font-size: larger;">Deptment</b>
    <input type="name" name="ddept" style="
    border-style: outset;
    border-color: snow;
    margin-left: 8%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

    <br><b style="font-size: larger;">State</b>
    <input type="name" name="dstate" style="
    border-style: outset;
    border-color: snow;
    margin-left: 4%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

    <br><b style="font-size: larger;">Contact</b>
    <input type="name" name="dcontact" style="
    border-style: outset;
    border-color: snow;
    margin-left: 4%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

    <br><b style="font-size: larger;">Email</b>
    <input type="name" name="dmail" style="
    border-style: outset;
    border-color: snow;
    margin-left: 8%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

     <br><b style="font-size: larger;">Date of Marriage</b>
    <input type="name" name="dmarriagedate" style="
    border-style: outset;
    border-color: snow;
    margin-left: 8%;
    padding-top: 1%;
    padding-left: 5%;
    padding-right: 5%;
    background-color: lightyellow;"><br>

    <input type="submit"name="tbl_doctor"value="OK" style="background-color:darkgreen;
    margin-top: 2%;
    margin-right: 18%;
    padding-top: 1%;
    padding-right: 2%;
    padding-left: 2%;
    padding-bottom: 1%;
    color: snow;
    border-color: forestgreen;">
</form>
</div>

<div>
    <?php
    include("db_connect.php");
    if(isset($_POST['tbl_doctor']));
    {
        $did = $_POST['did'];
        $dname = $_POST['dname'];
        $dspacification = $_POST['dspacification'];
        $dqualification = $_POST['dqualification'];
        $ddob = $_POST['ddob'];
        $ddept = $_POST['ddept'];
        $dstate = $_POST['dstate'];
        $dcontact = $_POST['dcontact'];
        $dmail = $_POST['dmail'];
        $dmarriagedate = $_POST['dmarriagedate'];

    $sql = "INSERT INTO tbl_doctor(did,dname,dspacification,dqualification,ddob,ddept,dstate,dcontact,dmail,dmarriagedate) VALUES ('$did','$dname','$dspacification','$qualification','$ddob','$ddept','$dstate','$dcontact','$dmail','$dmarriagedate')";

    $qry_run = mysqli_query($con,$sql);

    if($qry_run = = = TRUE)
    echo "<script> alert ('Registered') </script>";
    else
    echo "<script> alert ('Try Again!!!')</script>";
    }
?>
</div>
</body>
</html>
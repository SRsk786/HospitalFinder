<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
</head>
<body style= "background-color:snow;">
	<h2><b style="    margin-right: 10%;">FACILITIES</b></h2>
    <form action ="#" method="POST">

	<b style="font-size: large;">Treatement Name</b>
	<input type="" name="treatmentn"placeholder="MRI" style="margin-top: 2%;
    margin-bottom: 2%;
    padding-top: 1%;
    padding-right: 4%;
    padding-left: 4%;
    text-align: center;
    border-color: whitesmoke;
    background-color:   seashell;margin-left: 4%;"><br>


	<b style="font-size: large;margin-left: 5%;">CosT</b>
	<input type="" name="cost"placeholder="5000" style="margin-top: 2%;
    margin-bottom: 2%;
    padding-top: 1%;
    padding-right: 4%;
    padding-left: 4%;
    text-align: center;
    border-color: whitesmoke;
    background-color:   seashell;margin-left: 6%;"><br>

	<input type="button" name="button"value="OK" style="padding-top: 1%;
    padding-bottom: 1%;
    padding-right: 2%;
    padding-left: 2%;
    border-color: powderblue;
    margin-top: 2%;
    margin-left: 7%;
    margin-right: 6%;
    background-color: navy;
    color: white;">


</form>
</div>
<div>
    <!php
    include("db_connect.php");
    if(isset($_POST['hospital_reg']));
    {
        $treatmentn=$_POST['treatmentn'];
        $cost=$_POST['cost'];
        $="INSERT INTO tbl_hospital_reg(treatmentn,cost)VALUES('$treatmentn','$cost')";
        $qry_run=mysqli_query($con,$sql);
        if ($qry_run===TRUE)
        echo"<script>alert('Registered')</script>
        else
        echo"<script>alert('TRY AGAIN!!!')</script>"
    }
    ?>


    
    
</div>
</body>
</html>
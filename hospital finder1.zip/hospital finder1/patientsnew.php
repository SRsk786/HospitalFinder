<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
</head>
<h1><b style="margin-right: 20%;padding-left: 7%;">Patient Detail</b></h1>
<div>
<form action ="#" method="POST">
<body style="background-color: white;text-align: center;">
<b style="font-size: larger;">Patient ID</b>
	<input type="text" name="pid"style="margin-top: 2%;
    padding-top: 1%;
    padding-right: 10;
    padding-right: 10%;
    border-color: seashell;
    background-color: seashell;
    margin-left: 3%;"><br>

 <b style="font-size: larger;">Patient Name</b>
	<input type="text" name="pname"style="margin-top: 2%;
    padding-top: 1%;
    padding-right: 10;
    padding-right: 10%;
    border-color: seashell;
    background-color: seashell;
    margin-left: 1%;"><br>


	<b style="font-size: larger;">Gender</b>
	<input type="text" name="pgender"style="margin-top: 2%;
    padding-top: 1%;
    padding-right: 10;
    padding-right: 10%;
    border-color: seashell;
    background-color: seashell;
    margin-left: 4%;"><br>

    <b style="font-size: larger;">Age</b>
    <input type="text" name="page"style="margin-top: 2%;
    padding-top: 1%;
    padding-right: 10;
    padding-right: 10%;
    border-color: seashell;
    background-color: seashell;
    margin-left: 4%;"><br>

    <b style="font-size: larger;">Address</b>
	<input type="text" name="paddress" style="margin-top: 2%;
    padding-top: 1%;
    padding-right: 10;
    padding-right: 10%;
    border-color: seashell;
    background-color: seashell;
    margin-left: 6%;"><br>


	<b style="font-size: larger;">Contact</b>
	<input type="text" name="pcontact"style="margin-top: 2%;
    padding-top: 1%;
    padding-right: 10;
    padding-right: 10%;
    border-color: seashell;
    background-color: seashell;
    margin-left: 4%;"><br>

    <b style="font-size: larger;">Problem</b>
	<input type="text" name="pproblem"style="margin-top: 2%;
    padding-top: 1%;
    padding-right: 10;
    padding-right: 10%;
    border-color: seashell;
    background-color: seashell;
    margin-left: 2%;"><br>

    <b style="font-size: larger;">DOB</b>
	<input type="text" name="pdob"style="margin-top: 2%;
    padding-top: 1%;
    padding-right: 10;
    padding-right: 10%;
    border-color: seashell;
    background-color: seashell;
    margin-left: 6%;"><br>

<input type="submit" name="tbl_patients"value="OK" style="background-color:darkgreen;
    margin-left: 1%;
    padding-top: 1%;
    padding-right: 2%;
    padding-left: 2%;
    padding-bottom: 1%;
    margin-top: 3%;
    color: snow;
    border-color: forestgreen;">
</form>
</div>

<div>
    <?php
    include("db_connect.php");
    if(isset($_POST[tbl_patients]))
    {
        $pid = $_POST['pid'];
        $pname = $_POST['pname'];
        $pgender = $_POST['pgender'];
        $page = $_POST['page'];
        $paddress = $_POST['paddress'];
        $pcontact = $_POST['pcontact'];
        $pproblem = $_POST['pproblem'];
        $pdob = $_POST['pdob'];
        $pemail = $_POST['pemail'];


$sql = "INSERT INTO tbl_patients(pid,pname,pgender,page,paddress,pcontact,pproblem,pdob,pemail)VALUES('$pid',$pname','$pgender','$page','$padderss','$pcontact','$pproblem','$pdob','$pemail')";

$qry_run = mysql_query($con,$sql);
if ($qry_run === TRUE)
  echo"<script>alert('Registered')</script>";
  else
  echo"<script>alert('TRY AGAIN !!!')</script>";
}
?>
</div>
</body>
</html>